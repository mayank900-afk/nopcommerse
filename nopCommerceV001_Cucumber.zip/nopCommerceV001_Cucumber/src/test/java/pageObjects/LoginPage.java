package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPage {
	public WebDriver ldriver;

	public LoginPage(WebDriver rdriver) {
		rdriver = ldriver;
		PageFactory.initElements(rdriver, this);

	}

	@FindBy(id = "Email")
	@CacheLookup
	WebElement txtEmail;

	@FindBy(id = "Password")
	@CacheLookup
	WebElement txtpwd;

	@FindBy(xpath = "//button[normalize-space()='Log in']")
	@CacheLookup
	WebElement btnlogin;

	@FindBy(linkText = "Logout")
	@CacheLookup
	WebElement btnlogout;

	public void setUserName(String uname) {
		txtEmail.clear();
		txtEmail.sendKeys(uname);
	}

	public void setPassword(String Password) {
		txtpwd.clear();
		txtpwd.sendKeys(Password);

	}

	public void Loginbutton() {
		btnlogin.click();
	}

	public void Logoutbutton() {
		btnlogout.click();
	}

}
